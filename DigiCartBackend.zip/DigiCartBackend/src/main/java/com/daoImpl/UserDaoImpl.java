package com.daoImpl;

import java.util.ArrayList;
import java.util.List;

import com.Model.User;
import com.dao.UserDao;

public class UserDaoImpl implements UserDao{

	List<User> list;
	 public UserDaoImpl(){
		 list = new ArrayList<User>();
		 User user = new User("Shubham","shubham123","shubham123@gmail.com","Ghatkopar,Mumbai","8978546612","India");
	      list.add(user);		
	   }
	/* public List<User> display(String name, String password, String email, String address, String phone,
			String country) {
		return list;
	} */
	 public List<User> show() {
		return list;
	}

}
