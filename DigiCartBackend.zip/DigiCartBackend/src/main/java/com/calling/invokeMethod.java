package com.calling;


import com.Model.User;
import com.dao.UserDao;
import com.daoImpl.UserDaoImpl;

public class invokeMethod {
public static void main(String[] args) {
	UserDao user=new UserDaoImpl();
	for(User u: user.show()){
		System.out.println("\tName: "+u.getName()+"\n\tpassword: "+u.getPassword()+"\n\tAddress: "+u.getAddress()+"\n\tPhone: "+u.getPhone()+"\n\tEmal id: "+u.getEmail()+"\n\tCountry:"+u.getCountry());
	
	}
}
}
