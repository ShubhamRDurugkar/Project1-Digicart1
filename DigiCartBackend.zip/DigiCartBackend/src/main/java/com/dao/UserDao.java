package com.dao;

import java.util.List;

import com.Model.User;

public interface UserDao {
// public List<User> display(String name,String password,String email,String address,String phone,String country);
public List<User> show();
}
